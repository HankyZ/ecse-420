Abdullahi Elmi [2:36 PM]   
https://github.com/CypherElmi/Prometheus-Neural-Network

Java
Added to IntelliJ
run Drone.main()