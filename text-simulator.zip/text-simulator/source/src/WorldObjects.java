//interface for all world objects: ImmovableObj, MoveableObj, Robots

public interface WorldObjects {
	public String getName();
	public int getX();
	public int getY();
}